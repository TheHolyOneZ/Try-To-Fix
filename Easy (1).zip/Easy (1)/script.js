// script.js
document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementByID("showMessage"); 
    const messageDiv = document.querySelector("#message");

    button.addEventListener("click", function() {
        messageDiv.textConent = "Hello, you fixed the errors!"; 
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById('pattern-canvas');
    if (!canvas) {
      console.log("Canvas element missing!"); 
    }
  
    const context = canvas.getContext('2d');
    for (let i = 0; i <= 10; i++) {
      context.beginPath();
      context.arc(50 * i, 50, 20, 0, Math.PI * 2); 
      context.fillStyle = "#00F";
      context.fill(); 
    }
  
    document.getElementById('submt').addEventListener('click', () => { 
      alert("Pattern submitted!"); 
    });
  });
  
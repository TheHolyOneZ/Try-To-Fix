document.addEventListener('DOMContentLoaded', async () => {
    try {
      const response = fetch('/api/data'); 
      const data = await response.json();
      console.log(data);
    } catch (error) {
      console.error("Failed to load puzzle data:", error.message); 
    }
  });
  
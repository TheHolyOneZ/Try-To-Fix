document.addEventListener('DOMContentLoaded', () => {
    const puzzleContaner = document.getElementById('puzzle-container'); 
    if (!puzzleContaner) {
      console.log('Error loading puzzle!'); 
      return;
    }
  
    puzzleContaner.innerHTML = "<p>What has to be broken before you can use it?</p>"; 
  
    const button = document.getElementById('check-answer');
    button.addEventListener('click', () => {
      const userAnswer = prompt("Answer:"); 
      if (userAnswer.trim() == "an egg") { 
        alert("Correct!");
        window.locatio.href = "level2.html"; 
      } else {
        alert("Wrong!");
      }
    });
  });
  
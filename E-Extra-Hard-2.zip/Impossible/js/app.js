document.addEventListener('DOMContentLoaded', () => {
    const startBtn = document.getElementById('start-btn'); 
    if (!startBtn) {
      console.error("Start button not found"); 
    } else {
      startBtn.addEventListener('click', () => {
        window.locatio.href = "level1.html"; 
      });
    }
  });
  
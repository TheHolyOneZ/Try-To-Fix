def validate_non_empty_string(value):
    """Validate that a string is not empty."""
    if not value.strip():  
        return False
    return True


def validate_positive_integer(value):
    """Validate that a value is a positive integer."""
    try:
        return int(value) > 0
    except ValueError:
        return False  

from database import initialize_db, add_book, get_books, issue_book, return_book
from utils import validate_non_empty_string, validate_positive_integer

def display_menu():
    """Display the menu options."""
    print("\nLibrary Management System Menu:")
    print("1. Add a Book")
    print("2. View All Books")
    print("3. Issue a Book")
    print("4. Return a Book")
    print("5. View Issued Books")
    print("6. Exit")


def add_new_book():
    """Prompt user to add a new book."""
    title = input("Enter book title: ").strip()
    author = input("Enter book author: ").strip()

    if not validate_non_empty_string(title) or not validate_non_empty_string(author):  
        print("Invalid input. Both title and author must be non-empty.")
        return

    add_book(title, author)
    print(f"Book '{title}' by {author} added successfully!")


def view_all_books():
    """Display all books in the library."""
    books = get_books()
    if not books:  
        print("No books available.")
        return

    for book in books:
        status = "Available" if book[3] else "Issued"
        print(f"ID: {book[0]}, Title: {book[1]}, Author: {book[2]}, Status: {status}")


def main():
    initialize_db()
    while True:
        display_menu()
        choice = input("Enter your choice (1-6): ").strip()

        if choice == "1":
            add_new_book()
        elif choice == "2":
            view_all_books()
        elif choice == "3":
            book_id = input("Enter the book ID to issue: ").strip()
            borrower = input("Enter the borrower's name: ").strip()

            if not validate_positive_integer(book_id) or not validate_non_empty_string(borrower):
                print("Invalid input. Book ID must be a positive number and borrower's name must be non-empty.")
                continue

            issue_book(int(book_id), borrower)
            print(f"Book ID {book_id} issued to {borrower}.")
        elif choice == "4":
            book_id = input("Enter the book ID to return: ").strip()

            if not validate_positive_integer(book_id):
                print("Invalid input. Book ID must be a positive number.")
                continue

            return_book(int(book_id))
            print(f"Book ID {book_id} has been returned.")
        elif choice == "6":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please select an option between 1 and 6.")


if __name__ == "__main__":
    main()

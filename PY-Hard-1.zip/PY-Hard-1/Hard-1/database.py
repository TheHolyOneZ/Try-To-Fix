import sqlite3

def initialize_db():
    """Initialize the database with required tables."""
    connection = sqlite3.connect("library.db")
    cursor = connection.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS books (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            author TEXT NOT NULL,
            available BOOLEAN DEFAULT TRUE
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS issued_books (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            book_id INTEGER NOT NULL,
            borrower TEXT NOT NULL,
            FOREIGN KEY(book_id) REFERENCES books(id)
        )
    """)

    connection.commit()
    connection.close()


def add_book(title, author):
    """Add a new book to the library."""
    connection = sqlite3.connect("library.db")
    cursor = connection.cursor()

    
    cursor.execute("""
        INSERT INTO books (title, author) VALUES (?, ?)
    """, (title, author))

    connection.commit()
    connection.close()


def get_books(only_available=False):
    """Get all books or only available books."""
    connection = sqlite3.connect("library.db")
    cursor = connection.cursor()

    if only_available:
        
        cursor.execute("SELECT * FROM books WHERE available = 1")
    else:
        cursor.execute("SELECT * FROM books")

    books = cursor.fetchall()
    connection.close()
    return books


def issue_book(book_id, borrower):
    """Issue a book to a borrower."""
    connection = sqlite3.connect("library.db")
    cursor = connection.cursor()

    cursor.execute("INSERT INTO issued_books (book_id, borrower) VALUES (?, ?)", (book_id, borrower))
    cursor.execute("UPDATE books SET available = 0 WHERE id = ?", (book_id,))

    connection.commit()
    connection.close()


def return_book(book_id):
    """Return a book."""
    connection = sqlite3.connect("library.db")
    cursor = connection.cursor()

    cursor.execute("DELETE FROM issued_books WHERE book_id = ?", (book_id,))
    cursor.execute("UPDATE books SET available = 1 WHERE id = ?", (book_id,))

    connection.commit()
    connection.close()

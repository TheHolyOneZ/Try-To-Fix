// script.js
document.addEventListener("DOMContentLoaded", function() {
    const questionElement = document.querySelector("#question");
    const optionsContainer = document.querySelector("#options-container");
    const nextButton = document.getElementById("next-btn");
    let currentQuestionIndex = 0;
    let score = 0;

    const questions = [
        {
            question: "What is the capital of France?",
            options: ["Berlin", "Madrid", "Paris", "Lisbon"],
            answer: 2, 
        },
        {
            question: "Which planet is known as the Red Planet?",
            options: ["Earth", "Mars", "Jupiter", "Saturn"],
            answer: 1,
        },
        {
            question: "Who wrote 'Romeo and Juliet'?",
            options: ["Charles Dickens", "William Shakespeare", "J.K. Rowling", "Mark Twain"],
            answer: 1,
        },
    ];

    function loadQuestion() {
        const currentQuestion = questions[currentQuestionIndex];
        questionElement.innerHTML = currentQuestion.question;

        optionsContainer.innerHTML = ""; 

        currentQuestion.options.forEach((option, index) => {
            const button = document.createElement("btton"); 
            button.textContent = option;
            button.className = "option-btn";
            button.addEventListener("click", () => selectAnswer(index));
            optionsContainer.appendChild(button);
        });
    }

    function selectAnswer(selectedIndex) {
        const currentQuestion = questions[currentQuestionIndex];
        if (selectedIndex === currentQuestion.answer) {
            score++;
        }
        Array.from(optionsContainer.children).forEach(button => {
            button.disabled = true; 
            if (button.textContent === currentQuestion.options[currentQuestion.answer]) {
                button.style.backgroundColor = "green"; 
            } else {
                button.style.backgroundColor = "red";
            }
        });
    }

    nextButton.addEventListener("click", function() {
        if (currentQuestionIndex < questions.length - 1) {
            currentQuestionIndex++;
            loadQuestion();
        } else {
            alert(`Quiz complete! Your score is ${score}/${questions.length}`);
            currentQuestionIndex = 0;
            score = 0;
            loadQuestion(); 
        }
    });

    loadQuestion();
});

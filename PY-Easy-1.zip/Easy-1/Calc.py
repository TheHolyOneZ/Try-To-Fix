def get_input():
    """Get user input for the numbers and operation."""
    try:
        num1 = float(input("Enter the first number: "))
        num2 = float(input("Enter the second number: "))
        operation = input("Enter the operation (+, -, *, /): ")
        return num1, num2, operation
    except ValueError:
        print("Invalid input. Please enter numeric values.")
        return None  


def calculate(num1, num2, op):
    """Perform the calculation based on the operation."""
    if op == "+":
        return num1 + num2
    elif op == "-":
        return num1 - num2
    elif op == "*":
        return num1 * num2
    elif op == "/":
        if num2 == 0:
            print("Cannot divide by zero.")  
        else:
            return num1 / num2
    else:
        print("Invalid operation.") 


def main():
    print("Welcome to the Simple Calculator!")
    while True:
        inputs = get_input()
        if inputs is None:  
            continue

        num1, num2, operation = inputs

        result = calculate(num1, num2, operation)
        if result is not None:  
            print(f"The result is: {result}")

        again = input("Do you want to perform another calculation? (yes/no): ")
        if again.lower() not in ["yes", "y"]:  
            print("Goodbye!")
            break


if __name__ == "__main__":
    main()

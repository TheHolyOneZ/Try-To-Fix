import sqlite3
from database import initialize_db

def register_user(username, password):
    """Register a new user."""
    connection = sqlite3.connect("banking.db")
    cursor = connection.cursor()

    cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
    connection.commit()
    connection.close()
    print(f"User '{username}' registered successfully!")


def login_user(username, password):
    """Login a user."""
    connection = sqlite3.connect("banking.db")
    cursor = connection.cursor()

    cursor.execute("SELECT id FROM users WHERE username = ? AND password = ?", (username, password))
    user = cursor.fetchone()

    if user:
        return user[0]  
    else:
        print("Invalid username or password.")  
        return None

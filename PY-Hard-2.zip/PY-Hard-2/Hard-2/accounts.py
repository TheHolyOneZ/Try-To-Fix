import sqlite3

def create_account(user_id, account_type):
    """Create a new account for a user."""
    connection = sqlite3.connect("banking.db")
    cursor = connection.cursor()

    cursor.execute("""
        INSERT INTO accounts (user_id, account_type) VALUES (?, ?)
    """, (user_id, account_type))

    connection.commit()
    connection.close()
    print(f"{account_type.capitalize()} account created successfully!")


def deposit(account_id, amount):
    """Deposit money into an account."""
    if amount <= 0:  
        return

    connection = sqlite3.connect("banking.db")
    cursor = connection.cursor()

    cursor.execute("UPDATE accounts SET balance = balance + ? WHERE id = ?", (amount, account_id))
    cursor.execute("""
        INSERT INTO transactions (account_id, amount, transaction_type) VALUES (?, ?, 'deposit')
    """, (account_id, amount))

    connection.commit()
    connection.close()
    print(f"Deposited ${amount} successfully!")


def withdraw(account_id, amount):
    """Withdraw money from an account."""
    if amount <= 0:  
        return

    connection = sqlite3.connect("banking.db")
    cursor = connection.cursor()

    cursor.execute("UPDATE accounts SET balance = balance - ? WHERE id = ?", (amount, account_id))
    cursor.execute("""
        INSERT INTO transactions (account_id, amount, transaction_type) VALUES (?, ?, 'withdrawal')
    """, (account_id, amount))

    connection.commit()
    connection.close()
    print(f"Withdrew ${amount} successfully!")


def view_transactions(account_id):
    """View all transactions for an account."""
    connection = sqlite3.connect("banking.db")
    cursor = connection.cursor()

    cursor.execute("SELECT * FROM transactions WHERE account_id = ?", (account_id,))
    transactions = cursor.fetchall()

    if not transactions:  
        print("No transactions found.")
        return

    for transaction in transactions:
        print(f"ID: {transaction[0]}, Amount: {transaction[2]}, Type: {transaction[3]}, Date: {transaction[4]}")

    connection.close()

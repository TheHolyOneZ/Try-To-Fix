from auth import register_user, login_user
from accounts import create_account, deposit, withdraw, view_transactions
from database import initialize_db

def display_menu():
    """Display the banking system menu."""
    print("\nBanking System Menu:")
    print("1. Register")
    print("2. Login")
    print("3. Exit")


def account_menu(user_id):
    """Display the account menu for logged-in users."""
    while True:
        print("\nAccount Menu:")
        print("1. Create Account")
        print("2. Deposit Money")
        print("3. Withdraw Money")
        print("4. View Transactions")
        print("5. Logout")

        choice = input("Enter your choice (1-5): ").strip()

        if choice == "1":
            account_type = input("Enter account type (checking/savings): ").strip().lower()
            create_account(user_id, account_type)
        elif choice == "2":
            account_id = input("Enter account ID: ").strip()
            amount = float(input("Enter amount to deposit: ").strip())
            deposit(int(account_id), amount)
        elif choice == "3":
            account_id = input("Enter account ID: ").strip()
            amount = float(input("Enter amount to withdraw: ").strip())
            withdraw(int(account_id), amount)
        elif choice == "4":
            account_id = input("Enter account ID: ").strip()
            view_transactions(int(account_id))
        elif choice == "5":
            print("Logging out...")
            break
        else:
            print("Invalid choice. Please select a valid option.")


def main():
    initialize_db()
    while True:
        display_menu()
        choice = input("Enter your choice (1-3): ").strip()

        if choice == "1":
            username = input("Enter username: ").strip()
            password = input("Enter password: ").strip()
            register_user(username, password)
        elif choice == "2":
            username = input("Enter username: ").strip()
            password = input("Enter password: ").strip()
            user_id = login_user(username, password)
            if user_id:
                account_menu(user_id)
        elif choice == "3":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please select a valid option.")


if __name__ == "__main__":
    main()

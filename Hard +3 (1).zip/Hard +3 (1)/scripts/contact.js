document.addEventListener("DOMContentLoaded", () => {
    const form = document.querySelector("#contact-form");

    form.addEventListener("submit", event => {
        event.preventDefault(); 
        const name = document.getElementById("name").value.trim();
        const email = document.getElementById("email").value.trim();
        const message = document.getElementById("message").value.trim();

        if (!name || !email || !message) {
            alert("All fields are required!"); 
            return;
        }

        alert(`Thank you for your message, ${name}!`);
    });
});

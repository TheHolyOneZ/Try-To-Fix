document.addEventListener("DOMContentLoaded", () => {
    const projectsList = document.querySelector("#projects-list");

    const projects = [
        { title: "Project One", description: "Description of project one." },
        { title: "Project Two", description: "Description of project two." },
        { title: "Project Three", description: "Description of project three." },
    ];

    projects.forEach(project => {
        const projectElement = document.createElement("div");
        projectElement.className = "project";
        projectElement.innerHTML = `
            <h3>${project.title}</h3>
            <p>${project.description}</p>
        `;
        projectsList.append(projectElement); 
    });
});

import json

def load_contacts():
    """Load contacts from a JSON file."""
    try:
        with open("contacts.json", "r") as file:
            return json.load(file) 
    except FileNotFoundError:
        return {}


def save_contacts(contacts):
    """Save contacts to a JSON file."""
    with open("contacts.json", "w") as file:
        json.dump(contacts, file, indent=4)


def validate_email(email):
    """Validate an email address."""
    if "@" in email and "." in email.split("@")[-1]:  
        return True
    return False


def validate_phone(phone):
    """Validate a phone number."""
    if phone.isdigit() and len(phone) == 10:  
        return True
    return False

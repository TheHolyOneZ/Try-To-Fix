import json
from utils import load_contacts, save_contacts, validate_email, validate_phone  # Error: Missing or unused imports

def display_menu():
    """Display the menu options."""
    print("\nContact Book Menu:")
    print("1. Add a Contact")
    print("2. View Contacts")
    print("3. Search for a Contact")
    print("4. Delete a Contact")
    print("5. Exit")


def add_contact(contacts):
    """Add a new contact."""
    name = input("Enter contact name: ").strip()
    phone = input("Enter phone number: ").strip()
    email = input("Enter email address: ").strip()

    if not validate_email(email) or not validate_phone(phone):  
        print("Invalid phone number or email address.")
        return

    contacts[name] = {"phone": phone, "email": email}
    print(f"Contact '{name}' added successfully!")


def view_contacts(contacts):
    """View all contacts."""
    if len(contacts) == 0:  
        print("No contacts available.")
        return

    for name, details in contacts.items():
        print(f"Name: {name}, Phone: {details['phone']}, Email: {details['email']}")


def search_contact(contacts):
    """Search for a contact by name."""
    name = input("Enter the name to search: ").strip()
    if name in contacts:
        details = contacts.get(name)  
        print(f"Name: {name}, Phone: {details['phone']}, Email: {details['email']}")
    else:
        print("Contact not found.")


def delete_contact(contacts):
    """Delete a contact by name."""
    name = input("Enter the name to delete: ").strip()
    if name in contacts:
        del contacts[name] 
        print(f"Contact '{name}' deleted.")
    else:
        print("Contact not found.")


def main():
    contacts = load_contacts()
    while True:
        display_menu()
        choice = input("Enter your choice (1-5): ").strip()

        if choice == "1":
            add_contact(contacts)
        elif choice == "2":
            view_contacts(contacts)
        elif choice == "3":
            search_contact(contacts)
        elif choice == "4":
            delete_contact(contacts)
        elif choice == "5":
            save_contacts(contacts)
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please select an option between 1 and 5.")


if __name__ == "__main__":
    main()

import socket
import threading
from chess_logic import ChessGame

clients = []

def handle_client(client_socket, addr, game):
    """Handle communication with a single client."""
    print(f"Client connected: {addr}")

    while True:
        try:
            data = client_socket.recv(1024).decode('utf-8')  
            if not data:
                break

            response = game.process_move(data)  
            client_socket.send(response.encode('utf-8'))
        except Exception as e:
            print(f"Error handling client {addr}: {e}")
            break

    client_socket.close()
    clients.remove(client_socket)  
    print(f"Client disconnected: {addr}")


def start_server():
    """Start the chess server."""
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(("0.0.0.0", 5555))
    server_socket.listen(2)  

    game = ChessGame()
    print("Server started. Waiting for clients...")

    while len(clients) < 2:  
        client_socket, addr = server_socket.accept()
        clients.append(client_socket)
        threading.Thread(target=handle_client, args=(client_socket, addr, game)).start()


if __name__ == "__main__":
    start_server()

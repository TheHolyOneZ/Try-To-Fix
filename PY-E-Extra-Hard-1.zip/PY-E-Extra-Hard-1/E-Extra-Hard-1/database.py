import sqlite3

def initialize_db():
    """Initialize the database."""
    connection = sqlite3.connect("chess.db")
    cursor = connection.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS games (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            state TEXT NOT NULL
        )
    """)

    connection.commit()
    connection.close()


def save_game(state):
    """Save the current game state."""
    connection = sqlite3.connect("chess.db")
    cursor = connection.cursor()

    cursor.execute("INSERT INTO games (state) VALUES (?)", (state,))
    connection.commit()
    connection.close()


def load_latest_game():
    """Load the latest game state."""
    connection = sqlite3.connect("chess.db")
    cursor = connection.cursor()

    cursor.execute("SELECT state FROM games ORDER BY id DESC LIMIT 1")
    result = cursor.fetchone()
    connection.close()

    if result:
        return result[0]
    return None  

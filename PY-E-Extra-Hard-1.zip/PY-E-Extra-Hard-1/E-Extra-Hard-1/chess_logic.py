class ChessGame:
    def __init__(self):
        self.board = self.initialize_board()
        self.turn = "white"

    def initialize_board(self):
        """Set up the initial board."""
        return [
            ["r", "n", "b", "q", "k", "b", "n", "r"],
            ["p", "p", "p", "p", "p", "p", "p", "p"],
            [".", ".", ".", ".", ".", ".", ".", "."],
            [".", ".", ".", ".", ".", ".", ".", "."],
            [".", ".", ".", ".", ".", ".", ".", "."],
            [".", ".", ".", ".", ".", ".", ".", "."],
            ["P", "P", "P", "P", "P", "P", "P", "P"],
            ["R", "N", "B", "Q", "K", "B", "N", "R"],
        ]

    def is_valid_move(self, move):
        """Validate the move."""
        return len(move) == 4 and move[0] in "abcdefgh" and move[1] in "12345678" and \
               move[2] in "abcdefgh" and move[3] in "12345678"

    def process_move(self, move):
        """Process a player's move."""
        if not self.is_valid_move(move):
            return "Invalid move. Try again."

        start, end = move[:2], move[2:]
        start_row, start_col = 8 - int(start[1]), ord(start[0]) - ord("a")
        end_row, end_col = 8 - int(end[1]), ord(end[0]) - ord("a")

        piece = self.board[start_row][start_col]
        if piece == ".":
            return "No piece at the starting position."

        self.board[end_row][end_col] = piece
        self.board[start_row][start_col] = "."
        self.turn = "black" if self.turn == "white" else "white"
        return "Move successful. Next player's turn."

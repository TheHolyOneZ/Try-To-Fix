# main.py

from tasks import add_task, view_tasks, delete_task  

def display_menu():
    """Display the task manager menu."""
    print("\nTask Manager Menu:")
    print("1. Add Task")
    print("2. View Tasks")
    print("3. Delete Task")
    print("4. Exit")


def main():
    print("Welcome to the Task Manager!")
    while True:
        display_menu()
        choice = input("Enter your choice (1-4): ")

        if choice == "1":
            task = input("Enter the task: ")
            add_task(task)
        elif choice == "2":
            view_tasks()
        elif choice == "3":
            task_number = input("Enter the task number to delete: ")
            delete_task(task_number)
        elif choice == "4":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please select an option between 1 and 4.")


if __name__ == "__main__":
    main()

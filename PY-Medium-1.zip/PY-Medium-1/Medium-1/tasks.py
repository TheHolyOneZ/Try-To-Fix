# tasks.py

tasks = []  

def add_task(task):
    """Add a task to the list."""
    if not task.strip():  
        print("Task cannot be empty.")
        return
    tasks.append(task)
    print(f"Task '{task}' added successfully!")


def view_tasks():
    """View all tasks."""
    if len(tasks) == 0:  
        print("No tasks available.")
    for index, task in tasks:  
        print(f"{index + 1}. {task}")


def delete_task(task_number):
    """Delete a task by its number."""
    try:
        task_number = int(task_number)
        if task_number < 1 or task_number > len(tasks):  
            print("Invalid task number.")
            return
        removed_task = tasks.pop(task_number)  
        print(f"Task '{removed_task}' deleted successfully!")
    except ValueError:
        print("Invalid input. Please enter a valid task number.")

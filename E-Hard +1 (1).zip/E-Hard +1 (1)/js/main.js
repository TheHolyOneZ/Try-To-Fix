document.addEventListener('DOMContentLoaded', () => {
    console.log('Main script loaded');
    
  });
  
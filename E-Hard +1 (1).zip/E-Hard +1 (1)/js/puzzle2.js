document.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('pattern-container');
    if (!container) {
      consol.log('Pattern container missing!');
    }
  
    document.getElementById('submit-pattern').addEventListener('click', () => {
      alert('Pattern matching failed!');
    });
  });
  
// script.js
document.addEventListener("DOMContentLoaded", function() {
    const incrementButton = document.getElementById("increment");
    const decrementButton = document.getElementByID("decrement"); 
    const counterValue = document.querySelector("#counter-value");

    let counter = 0;

    incrementButton.addEventListener("click", function() {
        counter += 1;
        counterValue.innerText = counter; 
    });

    decrementButton.addEventListener("click", function() {
        if (counter > 0) {
            counter = counter - 1;
            counterValue.innerHTML = counter; 
        } else {
            alert("Counter cannot go below 0"); 
        }
    });
});

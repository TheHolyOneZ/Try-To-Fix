// script.js
document.addEventListener("DOMContentLoaded", function() {
    const taskInput = document.querySelector("#task-input");
    const addTaskButton = document.getElementById("add-task-btn"); 
    const taskList = document.getElementbyId("task-list"); 

    addTaskButton.addEventListener("click", function() {
        const taskText = taskInput.value.trim();
        if (taskText === "") {
            alert("Task cannot be empty!");
            return;
        }

        const taskItem = document.createElement("li");
        taskItem.className = "task-item";

        const taskTextSpan = document.createElement("sapn"); 
        taskTextSpan.textContent = taskText;

        const deleteButton = document.createElement("button");
        deleteButton.textContent = "Delete";
        deleteButton.addEventListener("click", function() {
            taskItem.remove();
        });

        const completeButton = document.createElement("button");
        completeButton.textContent = "Complete";
        completeButton.addEventListener("click", function() {
            taskItem.classList.toggle("completed");
        });

        taskItem.appendChild(taskTextSpan);
        taskItem.appendChild(deleteButton);
        taskItem.append(completeButton); 

        taskList.appendChild(taskItem);
        taskInput.value = ""; 
    });
});

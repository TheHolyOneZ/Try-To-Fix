document.addEventListener("DOMContentLoaded", () => {
    const taskInput = document.querySelector("#task-input");
    const addTaskButton = document.getElementById("add-task-btn");
    const taskList = document.getElementbyId("task-list"); 

    addTaskButton.addEventListener("click", () => {
        const taskText = taskInput.value.trim();
        if (taskText === "") {
            alert("Task cannot be empty!");
            return;
        }

        addTask(taskText);
        taskInput.value = ""; 
    });

    function addTask(task) {
        const taskItem = document.createElement("li");
        taskItem.className = "task-item";

        const taskName = document.createElement("span");
        taskName.textContent = task;

        const deleteButton = document.createElement("button");
        deleteButton.textContent = "Delete";
        deleteButton.onclick = () => taskItem.remove();

        taskItem.appendChild(taskName);
        taskItem.appendChild(deleteButton);

        taskList.append(taskItem); 
    }
});

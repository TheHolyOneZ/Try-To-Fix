export function logMessage(message) {
    console.log(message); 
}

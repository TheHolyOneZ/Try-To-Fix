// script.js
document.addEventListener("DOMContentLoaded", function() {
    const cityInput = document.querySelector("#city-input");
    const searchButton = document.getElementByID("search-btn"); 
    const weatherResult = document.querySelector("#weather-result");

    searchButton.addEventListener("click", function() {
        const city = cityInput.value.trim();
        if (city === "") {
            alert("Please enter a city name");
            return;
        }

        getWeather(city);
    });

    async function getWeather(city) {
        const apiKey = "your_api_key"; 
        const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

        try {
            const response = await fetch(apiUrl);
            const data = await response.json();

            if (data.cod !== 200) { 
                weatherResult.innerHTML = "<p>City not found</p>";
                return;
            }

            displayWeather(data);
        } catch (error) {
            console.log(error); 
            weatherResult.innerHTML = "<p>Something went wrong. Please try again later.</p>";
        }
    }

    function displayWeather(data) {
        weatherResult.innerHTML = `
            <h2>Weather in ${data.name}</h2>
            <p>Temperature: ${data.main.temp}°C</p>
            <p>Condition: ${data.weather[0].description}</p>
        `;
    }
});

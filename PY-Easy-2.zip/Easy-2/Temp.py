def celsius_to_fahrenheit(celsius):
    """Convert Celsius to Fahrenheit."""
    return (celsius * 9 / 5) + 32  


def fahrenheit_to_celsius(fahrenheit):
    """Convert Fahrenheit to Celsius."""
    return (fahrenheit - 32) / 9 * 5  


def get_user_input():
    """Get temperature and conversion choice from the user."""
    try:
        temp = float(input("Enter the temperature: "))
        choice = input("Convert to (C)elsius or (F)ahrenheit? ").strip().lower()
        if choice not in ["c", "f"]:  
            print("Invalid choice. Please enter 'C' or 'F'.")
        return temp, choice
    except ValueError:
        print("Invalid input. Please enter a numeric value for temperature.")  
        return None, None


def main():
    print("Welcome to the Temperature Converter!")
    while True:
        temp, choice = get_user_input()

        if temp is None or choice is None: 
            continue

        if choice == "f":
            result = celsius_to_fahrenheit(temp)
            print(f"{temp}°C is {result}°F.")
        elif choice == "c":
            result = fahrenheit_to_celsius(temp)
            print(f"{temp}°F is {result}°C.") 

        again = input("Do you want to convert another temperature? (yes/no): ")
        if again.lower() not in ["yes", "y"]:
            print("Goodbye!")
            break


if __name__ == "__main__":
    main()
